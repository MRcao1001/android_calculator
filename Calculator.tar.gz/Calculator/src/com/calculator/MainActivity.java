package com.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity {

	private TextView txt;
	
	public double Num1=0;
	public double Num2=0;
	public int Mark=1;
	public double result=0;
	String S="";
	char sign;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btn7;
    private Button btn8;
    private Button btn9;
    private Button btn0;
    private Button btn_point;
    private Button btn_jia;
    private Button btn_jian;
    private Button btn_cheng;
    private Button btn_chu;
    private Button btn_kaifang;
    private Button btn_result;
    private Button btn_clear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        txt = (TextView) findViewById(R.id.textView1);
        btn1 =(Button) findViewById(R.id.button1);
        btn1.setOnClickListener(new mClick());

        btn2=(Button) findViewById(R.id.button2);
        btn2.setOnClickListener(new mClick2());
        
        btn3=(Button) findViewById(R.id.button3);
        btn3.setOnClickListener(new mClick3());

        btn4=(Button) findViewById(R.id.button4);
        btn4.setOnClickListener(new mClick4());
        
        btn5=(Button) findViewById(R.id.button5);
        btn5.setOnClickListener(new mClick5());
        
        btn6=(Button) findViewById(R.id.button6);
        btn6.setOnClickListener(new mClick6());
        
        btn7=(Button) findViewById(R.id.button7);
        btn7.setOnClickListener(new mClick7());
        
        btn8=(Button) findViewById(R.id.button8);
        btn8.setOnClickListener(new mClick8());
        
        btn9=(Button) findViewById(R.id.button9);
        btn9.setOnClickListener(new mClick9());
        
        btn0=(Button) findViewById(R.id.button0);
        btn0.setOnClickListener(new mClick0());
        
        btn_point=(Button) findViewById(R.id.button_point);
        btn_point.setOnClickListener(new mClick_point());
        
        btn_jia=(Button) findViewById(R.id.button1_jia);
        btn_jia.setOnClickListener(new mClick_jia());
        
        btn_jian=(Button) findViewById(R.id.button_jian);
        btn_jian.setOnClickListener(new mClick_jian());
        
        btn_cheng=(Button) findViewById(R.id.button_cheng);
        btn_cheng.setOnClickListener(new mClick_cheng());
        
        btn_chu=(Button) findViewById(R.id.button_chu);
        btn_chu.setOnClickListener(new mClick_chu());
        
        btn_result=(Button) findViewById(R.id.button_result);
        btn_result.setOnClickListener(new mClick_result());
        
        btn_clear=(Button) findViewById(R.id.button_clear);
        btn_clear.setOnClickListener(new mClick_clear());
        
        btn_kaifang=(Button) findViewById(R.id.button_kaifang);
        btn_kaifang.setOnClickListener(new mClick_kaifang());
    }
    
    class mClick implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			S+="1";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+1;
			}
			else
			{
				Num2=Num2*10+1;
			}
		}
    }
    class mClick2 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="2";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+2;
			}
			else
			{
				Num2=Num2*10+2;
			}
		}
    }
    class mClick3 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="3";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+3;
			}
			else
			{
				Num2=Num2*10+3;
			}
		}
    }
    class mClick4 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="4";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+4;
			}
			else
			{
				Num2=Num2*10+4;
			}
		}
    }
    
    class mClick5 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="5";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+5;
			}
			else
			{
				Num2=Num2*10+5;
			}
		}
    }
    
    class mClick6 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="6";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+6;
			}
			else
			{
				Num2=Num2*10+6;
			}
		}
    }
    
    class mClick7 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="7";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+7;
			}
			else
			{
				Num2=Num2*10+7;
			}
		}
    }
    
    class mClick8 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="8";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+8;
			}
			else
			{
				Num2=Num2*10+8;
			}
		}
    }
    
    class mClick9 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="9";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10+9;
			}
			else
			{
				Num2=Num2*10+9;
			}
		}
    }
    
    class mClick0 implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S+="0";
			txt.setText(S);
			// TODO Auto-generated method stub
			if(Mark==1)
			{
				Num1=Num1*10;
			}
			else
			{
				Num2=Num2*10;
			}
		}
    }
    
    class mClick_point implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
		}
    }
    
    class mClick_jia implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="+ ";
			sign='+';
			Mark=2;
			txt.setText(S);
			
		}
    }
    class mClick_jian implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="- ";
			sign='-';
			Mark=2;
			txt.setText(S);
			
		}
    }
    class mClick_cheng implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="× ";
			sign='*';
			Mark=2;
			txt.setText(S);
			
		}
    }
    class mClick_chu implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="÷ ";
			sign='/';
			Mark=2;
			txt.setText(S);
			
		}
    }
    
    class mClick_kaifang implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="√ ";
			sign='√';
			Mark=2;
			txt.setText(S);
			
		}
    }
    class mClick_result implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			S="=";
		    switch (sign) {
		    case '+':
		    	result = Num1 + Num2;
		        break;
		    case '-':
		        result = Num1 - Num2;
		        break;
		    case '*':
		        result = Num1 * Num2;
		        break;
		    case '/':
		        result = Num1 / Num2;
		        break;
		    case '√':
		    	result = Math.pow(Num1, 1/Num2);
		    
		    default:
		        break;
		    }
		    //S+=QString::number(result, 10);  //这个函数，result必须是int类型
		    S+=String.valueOf(result);//float转Qstring
		    //S+= result+'0'; //不能这样写，result大于等于10就会报错
		    txt.setText(S);
			
		}
    }
    
    class mClick_clear implements OnClickListener
    {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Num1=0;
			Num2=0;
			Mark=1;
			result=0;
			S="";
			txt.setText(S);
			
			
		}
    }
    
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    
}
